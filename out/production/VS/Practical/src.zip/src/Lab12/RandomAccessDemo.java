// Question 6: Write a Java program using RandomAccessFile to write records.

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessDemo {
    public static void main(String[] args) {
        try {
            RandomAccessFile raf = new RandomAccessFile("data.txt", "rw");

            raf.writeInt(101);
            raf.writeUTF("Savin");
            raf.writeDouble(50000);

            raf.seek(0);

            int id = raf.readInt();
            String name = raf.readUTF();
            double salary = raf.readDouble();

            System.out.println("ID: " + id);
            System.out.println("Name: " + name);
            System.out.println("Salary: " + salary);

            raf.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}