// Question 10: Write a Java program to sort a collection of integers.
package Practical.src.Lab13;

import java.util.ArrayList;
import java.util.Collections;

public class SortCollectionDemo {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();

        list.add(50);
        list.add(20);
        list.add(40);
        list.add(10);
        list.add(30);

        System.out.println("Before sorting: " + list);

        Collections.sort(list);

        System.out.println("After sorting: " + list);
    }
}